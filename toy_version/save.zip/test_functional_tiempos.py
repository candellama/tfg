import unittest
import time
from statistics import mean
from toy_mldsa import MLDSA

class TestSignatureMalleability(unittest.TestCase):
    def setUp(self):
        self.msg = b"Testing signature modification"

def create_test_for_level(level):
    def test_tampered_signature(self):
        ml_dsa = MLDSA(security_level=level)
        public_key, private_key = ml_dsa.generate_keypair()
        
        try:
            # 1. Generate a valid signature
            c, z, attempts = ml_dsa.sign(self.msg, private_key)
            
            # 2. Tamper with the signature
            
            # modify the first coefficient of the first polynomial of z by adding 1 modulo q
            z[0][0] = (z[0][0] + 1) % ml_dsa.q
            
            tampered_signature = (c, z, attempts)
            
            # 3. Verify the tampered signature with the original message
            is_valid = ml_dsa.verify(self.msg, tampered_signature, public_key)
            
            # 4. it must fail
            self.assertFalse(is_valid, "Critical: Verification passed even though the signature was tampered for level {level}")
            
        except RuntimeError as e:
            self.fail(f"Failed to sign at level {level} due to attempt limit: {e}")
    return test_tampered_signature

for lvl in [2, 3, 5]:
    setattr(TestSignatureMalleability, f"test_tampered_level_{lvl}", create_test_for_level(lvl))
# ---------------------------------------------------------

if __name__ == '__main__': 
    suite_perf = unittest.TestLoader().loadTestsFromTestCase(TestSignatureMalleability)
    unittest.TextTestRunner(verbosity=2).run(suite_perf)