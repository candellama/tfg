import hashlib
import os
from typing import Tuple, List

class MLDSA:
# 1- Initialization and parameters
    # function to initialize parameters based on security level
    def __init__(self, security_level: int = 2):
        self.security_level = security_level
        self.set_parameters()
    
    # function to set parameters based on security level
    def set_parameters(self):
        params = {
            2: {"k": 4, "l": 4, "eta": 2, "gamma1": 64, "gamma2": 32, "beta": 4, "tau": 2},
            3: {"k": 6, "l": 5, "eta": 2, "gamma1": 128, "gamma2": 64, "beta": 6, "tau": 3},
            5: {"k": 8, "l": 7, "eta": 2, "gamma1": 128, "gamma2": 128, "beta": 6, "tau": 3}
        }
        
        p = params.get(self.security_level, params[2])
        self.k = p["k"]  # number of rows in A matrix
        self.l = p["l"]  # number of columns in A matrix
        self.eta = p["eta"]  # eta parameter for key sampling
        self.n = 16 # real is 256 ring dimension
        self.q =  257 #8380417 modulus for coefficients
        self.tau = p["tau"] # number of non-zero coefficients in the challenge poly
    
        # Toy signing bounds
        self.gamma1 = p["gamma1"]
        self.gamma2 = p["gamma2"]
        self.beta = p["beta"]

# 2- Seed expansion
    # function to generate random seed for key generation
    # default seed size is 32 bytes (256 bits)
    def generate_seed(self) -> bytes:
        return os.urandom(32)
    
    # function to expand seed using SHAKE256 XOF into a pseudorandom byte stream of some length
    def expand_seed(self, seed: bytes, nonce: int, length: int) -> bytes:
        h = hashlib.shake_256()
        h.update(seed)
        h.update(nonce.to_bytes(2, "little"))  # robust (0..65535)
        return h.digest(length)
    
# 3- Sampling

    # function to obtain uniform matrix A k x l from seed rho
    def sample_uniform_matrix(self, rho: bytes) -> list:
        A = []
        for i in range(self.k):
            row = []
            for j in range(self.l):
                nonce = i * self.l + j
                # sample polynomial coefficients
                # chain of bytes representing the polynomial
                poly_bytes = self.expand_seed(rho, nonce, 4 * self.n)
                # Convert the bytes to polynomial coefficients mod q
                poly = self._bytes_to_coefficients_uniform_mod_q(poly_bytes)
                row.append(poly)
            A.append(row)
        return A
    
    # function to sample secret small polynomials s1 and s2, coefficients in [-eta, eta]
    def sample_bounded(self, sigma: bytes, nonce: int, eta: int, n: int) -> list:
        poly_bytes = self.expand_seed(sigma, nonce, n)
        coeffs = []
        for b in poly_bytes:
            coeffs.append((b % (2 * eta + 1)) - eta)
        return coeffs

    def _bytes_to_coefficients_uniform_mod_q(self, data: bytes) -> list:
        coeffs = []
        needed = 4 * self.n
        if len(data) < needed:
            raise ValueError(f"Need at least {needed} bytes, got {len(data)}")

        for i in range(self.n):
            chunk = data[4*i : 4*i + 4]
            val = int.from_bytes(chunk, "little") % self.q
            coeffs.append(val)
        return coeffs
    
# 4- Algebraic and ring arithmetic operations 
    def _centered_mod(self, x: int, m: int) -> int:
        x %= m
        if x > m // 2:
            return x - m
        return x

    def _poly_norm_inf(self, a: List[int]) -> int:
        return max(abs(self._centered_mod(x, self.q)) for x in a)

    def _vec_norm_inf(self, v: List[List[int]]) -> int:
        return max(self._poly_norm_inf(p) for p in v)
    

    # function to do: poly1 + scalar*poly2 of two polys expressed as lists of their polynomials
    def _poly_scalar_add(self, poly1: List[int], scalar: int, poly2: List[int]) -> List[int]:
        if scalar == 0:
            return [c1 % self.q for c1 in poly1]
        return [(c1 + scalar*c2) % self.q for c1, c2 in zip(poly1, poly2)]
    
    def _poly_add(self, a: List[int], b: List[int]) -> List[int]:
        return self._poly_scalar_add(a, 1, b)

    def _poly_sub(self, a: List[int], b: List[int]) -> List[int]:
        return self._poly_scalar_add(a, -1, b)

    # function to multiply two polynomials in R_q = Z_q[x]/(x^n + 1)
    def _poly_mul_negacyclic(self, a: List[int], b: List[int]) -> List[int]:
        """
        Multiply in R_q = Z_q[x]/(x^n + 1)
        """
        n = self.n
        q = self.q
        res = [0] * n
        for i in range(n):
            for j in range(n):
                prod = a[i] * b[j]
                idx = i + j
                # If idx >= n, wrap around and subtract because x^n == -1.
                if idx < n:
                    res[idx] = (res[idx] + prod) % q
                else:
                    res[idx - n] = (res[idx - n] - prod) % q
        return res


    
    def _matrix_mult_add(self, A: List[List[List[int]]], s1: List[List[int]], s2: List[List[int]]) -> List[List[int]]:
        """
        Compute t = A*s1 + s2 over the ring R_q (polynomial arithmetic).
        A: k x l matrix of polynomials (each polinomial is length-n list mod q)
        s1: length-l vector of polynomials
        s2: length-k vector of polynomials (small coefficients)
        """
        t = []
        for i in range(self.k):
            acc = [0] * self.n
            for j in range(self.l):
                acc = self._poly_add(acc, self._poly_mul_negacyclic(A[i][j], s1[j]))
            # add s2 (convert negatives to mod q if needed)
            acc = [(acc[k] + (s2[i][k] % self.q)) % self.q for k in range(self.n)]
            t.append(acc)
        return t
    
    # function to do matrix*vec of polynomials
    def _mat_vec_mul(self, A, v):
        zero_vec = [[0] * self.n for _ in range(self.k)]
        return self._matrix_mult_add(A, v, zero_vec)
    
    
# 5- highbits and lowbits

    # function to compute high and lowbits of a polynomial expressed as list of its coeffs
    def _highbits_poly(self, poly: List[int], gamma2: int) -> Tuple[List[int], List[int]]:
        highs, lows = [], []
        for c in poly:
            cc = self._centered_mod(c, self.q)  # centered mod q
            # low  = coeff mod gamma2
            low = self._centered_mod(cc, gamma2)       # symmetric remainder
            # high = (coeff - low)/gamma2
            high = (cc - low) // gamma2           # integer exact
            highs.append(high)
            lows.append(low)
        return highs, lows

    # extended function to compute the high and lowbits of a vector of polys
    def _highbits_vec(self, vec: List[List[int]], gamma2: int) -> Tuple[List[List[int]], List[List[int]]]:
        highs, lows = [], []
        for p in vec:
            h, l = self._highbits_poly(p, gamma2)
            highs.append(h)
            lows.append(l)
        return highs, lows

    def _lowbits_vec(self, vec: List[List[int]], gamma2: int) -> List[List[int]]:
        return [self._highbits_poly(p, gamma2)[1] for p in vec]

    def _encode_w1(self, w1: List[List[int]]) -> bytes:
        out = bytearray()
        for poly in w1:
            for x in poly:
                out.extend(int(x).to_bytes(2, "little", signed=True))
        return bytes(out)
    
    def _sample_In_Ball(self, seed: bytes)->List[int]:
        if self.tau > self.n:
            raise ValueError("tau must be <= n")
    
        c = [0] * self.n
        # use shake 256 to sample random bytes
        h = hashlib.shake_256()
        h.update(seed)
        random_bytes = h.digest(self.n*30)  # get enough random bytes
        sign_bytes = random_bytes[:8]  # first 8 bytes for signs
        random_bytes = random_bytes[8:]  # remaining bytes for indices
        
        sign_bits = []
        for b in sign_bytes:
            for k in range(8):
                sign_bits.append((b >> k) & 1)

        for i in range(self.n - self.tau, self.n):
            j = random_bytes[0]
            random_bytes = random_bytes[1:]
            while j>i:
                j = random_bytes[0]
                random_bytes = random_bytes[1:]
            c[i] = c[j]
            c[j] = (-1)**(sign_bits[i+self.tau-self.n])
        return c


#########################################################################################################
#########################################################################################################
# Toy version of Dilithium algorithms 
    # 1 KEYPAIR GENERATION FUNCTION 
    def generate_keypair(self, seed: bytes = None) -> Tuple[Tuple, Tuple]:

        if seed is None:
            seed = self.generate_seed()
        
        # Seed expansion
        h = hashlib.shake_256()
        h.update(b"KeyGen" + seed)
        expanded = h.digest(128)
        
        rho = expanded[:32]  # seed for A
        sigma = expanded[32:64]  # seed for s1 and s2
        
        # Sample matrix A
        A = self.sample_uniform_matrix(rho)
        
        # Sample secretes s1 and s2
        s1 = []
        s2 = []
        
        for i in range(self.l):
            nonce = i
            s1_poly = self.sample_bounded(sigma, nonce, self.eta, self.n)
            s1.append(s1_poly)
        
        for i in range(self.k):
            nonce = self.l + i
            s2_poly = self.sample_bounded(sigma, nonce, self.eta, self.n)
            s2.append(s2_poly)
        
        # Compute t = A * s1 + s2 (simplified matrix multiplication)
        t = self._matrix_mult_add(A, s1, s2)
        
        # Return raw components without encoding
        public_key = (rho, t)
        private_key = (rho, s1, s2, t)
        
        return public_key, private_key
    

    ############################################
    # 2 SIGNATURE GENERATION FUNCTION
    def sign(self, message: bytes, private_key: tuple, max_tries: int = 10000) -> Tuple[List[int], List[List[int]], int]:
        rho, s1, s2, _t = private_key
        A = self.sample_uniform_matrix(rho)

        for attempt in range(max_tries):
            # 1) sample y with small coefficients in [-gamma1, gamma1]
            y = [self.sample_bounded(os.urandom(32), i, self.gamma1, self.n) for i in range(self.l)]

            # 2) w = A*y
            w = self._mat_vec_mul(A, y)

            # 3) w1 = HighBits(w, gamma2)
            w1, _= self._highbits_vec(w, self.gamma2)

            # 4) c = H(m || w1) sparse polynomial in Btau 

            h = hashlib.shake_256()
            h.update(message)
            h.update(self._encode_w1(w1))
            c_tilde=h.digest(32)                   
            c = self._sample_In_Ball(c_tilde)

            # 5) z = y + c*s1
            z = [self._poly_add(y[i], self._poly_mul_negacyclic(c, s1[i])) for i in range(self.l)]

            # 6) rejection sampling 
            if self._vec_norm_inf(z) > (self.gamma1 - self.beta):
                continue

            # w0' = LowBits(w - c*s2, gamma2)
            w_minus = [self._poly_sub(w[i], self._poly_mul_negacyclic(c, s2[i])) for i in range(self.k)]
            w0_prime = self._lowbits_vec(w_minus, self.gamma2)

            # ||w0'||_inf <= gamma2 - beta
            if self._vec_norm_inf(w0_prime) > (self.gamma2 - self.beta):
                continue
            

            # 8) explicit verifier-side consistency check
            Az = self._mat_vec_mul(A, z)
            Az_minus_ct = [self._poly_sub(Az[i], self._poly_mul_negacyclic(c, _t[i])) for i in range(self.k)]
            w1_prime, _ = self._highbits_vec(Az_minus_ct, self.gamma2)

            h2 = hashlib.shake_256()
            h2.update(message)
            h2.update(self._encode_w1(w1_prime))
            c_tilde_prime = h2.digest(32)
            c_prime = self._sample_In_Ball(c_tilde_prime)

            if c_prime != c:
                continue

            return c, z, attempt

        raise RuntimeError(
            f"Signing failed after {max_tries} attempts "
            f"(try increasing gamma1/gamma2 or lowering eta/tau)."
        )

        #     return c, z, attempt

        # raise RuntimeError(f"Signing failed after {max_tries} attempts (try increasing gamma1/gamma2 or lowering beta).")


    #############################################
    # 3 SIGNATURE VERIFICATION FUNCTION
    def verify(self, message: bytes, signature: Tuple[List[int], List[List[int]], int]
               , public_key: tuple) -> bool:
        c, z, a = signature
        rho, t = public_key
        A = self.sample_uniform_matrix(rho)

        if len(c) != self.n:
            return False
        if any(x not in (-1, 0, 1) for x in c):
            return False
        if sum(1 for x in c if x != 0) != self.tau:
            return False

        if self._vec_norm_inf(z) > (self.gamma1 - self.beta):
            return False

        # w1' = HighBits(Az - c t)
        Az = self._mat_vec_mul(A, z)
        Az_minus_ct = [self._poly_sub(Az[i], self._poly_mul_negacyclic(c, t[i])) for i in range(self.k)]
        
        w1_prime, _ = self._highbits_vec(Az_minus_ct, self.gamma2)

        h = hashlib.shake_256()
        h.update(message)
        h.update(self._encode_w1(w1_prime))
        c_tilde_prime=h.digest(32)                   
        c_prime= self._sample_In_Ball(c_tilde_prime)

        return c_prime == c
    
if __name__ == "__main__":
    print("=== ML-DSA Toy Implementation Test ===\n")

    # 1. Initialize scheme
    dsa = MLDSA(security_level=2)

    # 2. Generate keypair
    print("[*] Generating keypair...")
    pk, sk = dsa.generate_keypair()
    print("[+] Keypair generated\n")

    # 3. Define message
    message = b"H"
    # # 4. Sign message
    print("[*] Signing message...")
    c, z, attempts = dsa.sign(message, sk)
    print(f"[+] Signature generated in {attempts + 1} attempt(s)\n")

    # 5. Verify signature
    print("[*] Verifying signature...")
    valid = dsa.verify(message, (c, z, attempts), pk)
    print(f"[+] Verification result: {valid}\n")

    # # 6. Negative test (modified message)
    print("[*] Testing modified message...")
    tampered_message = b"Hello, this is a tampered message."
    valid_tampered = dsa.verify(tampered_message, (c, z, attempts), pk)
    print(f"[+] Verification (tampered message): {valid_tampered}\n")

    # # 7. Negative test (modified signature)
    print("[*] Testing modified signature...")
    z_bad = [poly[:] for poly in z]
    z_bad[0][0] += 1  # small corruption
    valid_bad_sig = dsa.verify(message, (c, z_bad, attempts), pk)
    print(f"[+] Verification (tampered signature): {valid_bad_sig}\n")

    print("=== Test completed ===")